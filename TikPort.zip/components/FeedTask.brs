
sub init()

    m.top.functionName = "executeFeedRequest"

end sub


sub executeFeedRequest()

    print "[TikPort] FeedTask started."

    url = m.top.feedUrl

    if url = invalid or url = ""
        m.top.error = "No feed URL was provided."
        m.top.videos = []
        print "[TikPort] ERROR: Missing feed URL."
        return
    end if

    print "[TikPort] Requesting: " + url

    transfer = CreateObject("roUrlTransfer")
    transfer.SetUrl(url)

    transfer.AddHeader("Accept", "application/json")
    transfer.AddHeader("User-Agent", "TikPort-Roku/1.0")

    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()

    responseText = transfer.GetToString()

    if responseText = invalid or responseText = ""
        m.top.error = "The TikPort backend returned an empty response."
        m.top.videos = []
        print "[TikPort] ERROR: Empty HTTP response."
        return
    end if

    print "[TikPort] Received API response."
    print "[TikPort] Response length: " + responseText.Len().ToStr()

    parsed = ParseJson(responseText)

    if parsed = invalid
        m.top.error = "Could not parse the TikPort API response."
        m.top.videos = []
        print "[TikPort] ERROR: JSON parsing failed."
        return
    end if

    videos = invalid

    if Type(parsed) = "roArray"

        videos = parsed

    else if Type(parsed) = "roAssociativeArray"

        if parsed.videos <> invalid
            videos = parsed.videos

        else if parsed.data <> invalid

            if Type(parsed.data) = "roArray"
                videos = parsed.data

            else if Type(parsed.data) = "roAssociativeArray"

                if parsed.data.videos <> invalid
                    videos = parsed.data.videos
                end if

            end if

        end if

    end if

    if videos = invalid

        m.top.error = "The API response did not contain a videos array."
        m.top.videos = []

        print "[TikPort] ERROR: No videos array found."
        print "[TikPort] Response: " + responseText

        return

    end if

    if Type(videos) <> "roArray"

        m.top.error = "The API videos property was not an array."
        m.top.videos = []

        print "[TikPort] ERROR: Videos property is not an array."

        return

    end if

    print "[TikPort] Parsed " + videos.Count().ToStr() + " videos."

    m.top.videos = videos
    m.top.error = ""

    print "[TikPort] Feed loaded successfully."

end sub
