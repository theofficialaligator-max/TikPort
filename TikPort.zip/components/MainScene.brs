
sub init()

    m.apiBase = "http://192.168.1.150:3000"

    m.videos = []
    m.videoIndex = 0

    m.menuFocused = false
    m.navIndex = 0

    m.requestMode = ""
    m.loadingRelated = false

    m.video = m.top.findNode("videoPlayer")
    m.feedTask = m.top.findNode("feedTask")

    m.navSelection = m.top.findNode("navSelection")

    m.forYouScreen = m.top.findNode("forYouScreen")
    m.searchScreen = m.top.findNode("searchScreen")
    m.settingsScreen = m.top.findNode("settingsScreen")

    m.creatorAvatar = m.top.findNode("creatorAvatar")
    m.creatorText = m.top.findNode("creatorText")
    m.usernameText = m.top.findNode("usernameText")
    m.descriptionText = m.top.findNode("descriptionText")

    m.loadingText = m.top.findNode("loadingText")
    m.errorText = m.top.findNode("errorText")

    m.searchQueryText = m.top.findNode("searchQueryText")
    m.searchResultsText = m.top.findNode("searchResultsText")

    m.navLabels = [
        m.top.findNode("forYouLabel"),
        m.top.findNode("searchLabel"),
        m.top.findNode("settingsLabel")
    ]

    if m.feedTask = invalid
        print "[TikPort] ERROR: FeedTask node not found."
        return
    end if

    if m.video = invalid
        print "[TikPort] ERROR: Video node not found."
        return
    end if

    m.feedTask.observeField("state", "onTaskStateChanged")
    m.video.observeField("state", "onVideoStateChanged")

    m.top.setFocus(true)

    loadForYou()

end sub


' =========================================
' FEED REQUEST
' =========================================

sub startFeedRequest(url, mode, message)

    state = LCase(m.feedTask.state)

    if state = "run"
        print "[TikPort] Request already running."
        return
    end if

    m.requestMode = mode

    m.loadingText.text = message
    m.loadingText.visible = true

    m.errorText.visible = false

    m.feedTask.videos = []
    m.feedTask.error = ""
    m.feedTask.feedUrl = url

    print "[TikPort] Starting request: " + url

    m.feedTask.control = "RUN"

end sub


' =========================================
' INITIAL FEED
' =========================================

sub loadForYou()

    m.loadingRelated = false

    startFeedRequest(
        m.apiBase + "/api/feed?limit=50",
        "initial",
        "Loading TikTok videos..."
    )

end sub


' =========================================
' TASK COMPLETION
' =========================================

sub onTaskStateChanged()

    state = LCase(m.feedTask.state)

    print "[TikPort] Observed task state: " + state

    if state = "run"
        return
    end if

    if state <> "done" and state <> "failed" and state <> "stop"
        return
    end if

    m.loadingRelated = false

    if state = "failed"
        showError("The TikPort background task failed.")
        return
    end if

    taskError = m.feedTask.error

    if taskError <> invalid and taskError <> ""
        showError(taskError)
        return
    end if

    videos = m.feedTask.videos

    if videos = invalid
        showError("TikPort returned no video list.")
        return
    end if

    if Type(videos) <> "roArray"
        showError("TikPort returned an invalid video list.")
        return
    end if

    print "[TikPort] Task returned " + videos.Count().ToStr() + " videos."

    if m.requestMode = "related"
        appendRelatedVideos(videos)
        return
    end if

    m.videos = []

    for each item in videos
        m.videos.Push(item)
    end for

    m.videoIndex = 0

    if m.videos.Count() = 0
        showError("No playable videos were found.")
        return
    end if

    print "[TikPort] Calling playCurrentVideo..."

    playCurrentVideo()

end sub


' =========================================
' ERROR DISPLAY
' =========================================

sub showError(message)

    m.loadingText.visible = false

    m.errorText.text = message
    m.errorText.visible = true

    m.loadingRelated = false

    print "[TikPort] ERROR: " + message

end sub


' =========================================
' RELATED VIDEOS
' =========================================

sub appendRelatedVideos(incoming)

    added = 0

    for each newVideo in incoming

        duplicate = false

        for each oldVideo in m.videos

            if oldVideo.id = newVideo.id
                duplicate = true
                exit for
            end if

        end for

        if not duplicate
            m.videos.Push(newVideo)
            added = added + 1
        end if

    end for

    print "[TikPort] Added " + added.ToStr() + " related videos."

    if added = 0
        showError("No new related videos are available.")
        return
    end if

    m.videoIndex = m.videoIndex + 1

    playCurrentVideo()

end sub


sub loadRelatedVideos()

    if m.loadingRelated
        return
    end if

    if m.videos.Count() = 0
        return
    end if

    current = m.videos[m.videoIndex]

    if current.id = invalid
        showError("The current video has no ID.")
        return
    end if

    m.loadingRelated = true

    transfer = CreateObject("roUrlTransfer")
    escapedId = transfer.Escape(current.id.ToStr())

    url = m.apiBase + "/api/feed/next?videoId=" + escapedId

    startFeedRequest(
        url,
        "related",
        "Finding more videos..."
    )

end sub


' =========================================
' VIDEO PLAYBACK
' =========================================



sub playCurrentVideo()

    print "[TikPort] playCurrentVideo entered."

    if m.video = invalid
        showError("Video player is unavailable.")
        return
    end if

    if m.videoIndex < 0 or m.videoIndex >= m.videos.Count()
        showError("Invalid video selection.")
        return
    end if

    item = m.videos[m.videoIndex]

    if item.playback_url = invalid or item.playback_url = ""
        showError("This video has no playback URL.")
        return
    end if

    print "[TikPort] Preparing video " + (m.videoIndex + 1).ToStr()
    print "[TikPort] URL: " + item.playback_url

    m.video.control = "stop"
    m.video.visible = false

    content = CreateObject("roSGNode", "ContentNode")
    content.url = item.playback_url
    content.streamFormat = "mp4"

    if item.title <> invalid
        content.title = item.title
    end if

    if item.duration <> invalid
        content.length = item.duration
    end if

    m.video.content = content

    if item.creator <> invalid
        m.creatorText.text = item.creator
    else
        m.creatorText.text = "Unknown creator"
    end if

    if item.username <> invalid
        m.usernameText.text = "@" + item.username
    else
        m.usernameText.text = ""
    end if

    if item.title <> invalid
        m.descriptionText.text = item.title
    else
        m.descriptionText.text = ""
    end if

    m.errorText.visible = false
    m.loadingText.text = "Loading video..."
    m.loadingText.visible = true

    m.video.visible = true
    m.video.control = "play"

    print "[TikPort] Playback command sent."

end sub




' =========================================
' VIDEO STATE
' =========================================


sub onVideoStateChanged()

    state = LCase(m.video.state)

    print "[TikPort] Video state: " + state

    if state = "buffering"

        m.loadingText.text = "Buffering..."
        m.loadingText.visible = true

    else if state = "playing"

        m.loadingText.visible = false
        m.errorText.visible = false

    else if state = "error"

        showError("Roku could not play this video.")
        return

    else if state = "finished"

        m.loadingText.visible = false

        if m.videoIndex < m.videos.Count() - 1
            m.videoIndex = m.videoIndex + 1
            playCurrentVideo()
        else
            loadRelatedVideos()
        end if

    end if

end sub



' =========================================
' NAVIGATION
' =========================================

sub updateNavigation()

    positions = [250, 325, 400]

    m.navSelection.translation = [
        15,
        positions[m.navIndex]
    ]

end sub


sub showSection(section)

    m.forYouScreen.visible = false
    m.searchScreen.visible = false
    m.settingsScreen.visible = false

    if section = 0
        m.forYouScreen.visible = true
    else if section = 1
        m.searchScreen.visible = true
    else if section = 2
        m.settingsScreen.visible = true
    end if

end sub


' =========================================
' SEARCH
' =========================================

sub openSearch()

    keyboard = CreateObject("roSGNode", "KeyboardDialog")

    keyboard.title = "Search TikTok"
    keyboard.text = ""
    keyboard.buttons = ["Search", "Cancel"]

    keyboard.observeField(
        "buttonSelected",
        "onSearchKeyboardButton"
    )

    m.top.dialog = keyboard

end sub


sub onSearchKeyboardButton()

    dialog = m.top.dialog

    if dialog = invalid
        return
    end if

    selected = dialog.buttonSelected
    query = dialog.text

    m.top.dialog = invalid

    if selected <> 0
        return
    end if

    query = Trim(query)

    if query = ""
        return
    end if

    transfer = CreateObject("roUrlTransfer")
    escapedQuery = transfer.Escape(query)

    m.searchQueryText.text = "Searching for: " + query
    m.searchResultsText.text = "Searching..."

    m.loadingRelated = false

    url = m.apiBase + "/api/search?q=" + escapedQuery

    startFeedRequest(
        url,
        "search",
        "Searching TikTok..."
    )

end sub


' =========================================
' REMOTE INPUT
' =========================================

function onKeyEvent(key as String, press as Boolean) as Boolean

    if not press
        return false
    end if

    if m.menuFocused

        if key = "up"

            m.navIndex = m.navIndex - 1

            if m.navIndex < 0
                m.navIndex = 2
            end if

            updateNavigation()
            return true

        else if key = "down"

            m.navIndex = m.navIndex + 1

            if m.navIndex > 2
                m.navIndex = 0
            end if

            updateNavigation()
            return true

        else if key = "right"

            m.menuFocused = false
            m.top.setFocus(true)
            return true

        else if key = "OK"

            if m.navIndex = 0
                showSection(0)
            else if m.navIndex = 1
                showSection(1)
                openSearch()
            else if m.navIndex = 2
                showSection(2)
            end if

            m.menuFocused = false
            return true

        end if

    else

        if key = "left"

            m.menuFocused = true
            updateNavigation()
            return true

        else if key = "up"

            if m.videoIndex > 0
                m.videoIndex = m.videoIndex - 1
                playCurrentVideo()
            end if

            return true

        else if key = "down"

            if m.videoIndex < m.videos.Count() - 1
                m.videoIndex = m.videoIndex + 1
                playCurrentVideo()
            else
                loadRelatedVideos()
            end if

            return true

        else if key = "OK" or key = "play"

            if m.video.state = "playing"
                m.video.control = "pause"
            else
                m.video.control = "resume"
            end if

            return true

        end if

    end if

    return false

end function
